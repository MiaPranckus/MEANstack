"use strict";
/*Mia Pranckus
8-9-21
Phase 2 Section End Project: Cart Management: Typescript File*/
//var currentCount = 0;
var item;
var itemStrings;
var numItems;
var inShoppingCart = [];
var total = 0;
function addToCart(name, price) {
    //put itemName, itemPrice, in an array
    //create object
    item = { nm: name, p: price }; //qty:currentCount
    console.log(item);
    //push into array that has all cart items
    inShoppingCart.push(item);
    console.log(inShoppingCart);
    //set cart full of items in local storage
    localStorage.setItem("ShoppingCart", JSON.stringify(inShoppingCart));
    numItems = inShoppingCart.length;
    document.getElementById("cart_size").innerHTML = numItems;
}
function displayCart() {
    //retrieve the items from local storage
    console.log(localStorage.getItem("ShoppingCart"));
    var retrievedItems = localStorage.getItem("ShoppingCart");
    console.log("the retrieved items are: " + retrievedItems);
    var displayedItems = JSON.parse(retrievedItems);
    var tableContent = " ";
    var startTable = "<table id='cartTable'><tr><th>Item Name</th><th>Price</th></tr>"; //add quantity
    var priceRow = "<tr><th colspan=3>Total</th></tr>";
    displayedItems.forEach(function (element) {
        tableContent += "<tr><td>" + element.nm + "</td><td> $" + element.p + "</td></tr>"; //<td>"+element.qty+"</td>
        var itemPrice = +element.p;
        total += itemPrice;
        console.log(total);
    });
    var endTable = "</table>";
    tableContent = startTable + tableContent + priceRow + "<tr><td colspan=3> $" + total.toString() + "</tr></td>" + endTable;
    document.getElementById("main").innerHTML = tableContent;
}
