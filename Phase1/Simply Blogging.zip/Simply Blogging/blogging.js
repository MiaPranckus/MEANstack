//Mia Pranckus
//8-4-21
//Phase End Project: Simply Blogging: Javascript File

var title;
var articles;
var url_link;

var img='<img src="';
var img_end='" style="max-width:80%; max-height:80%; object-fit:contain">';

var count=0;

function add_blog() {
	
	//access the user inputs
	title = document.getElementById("title_input").value;
		console.log(title);
	articles = document.getElementById("articles").value;
		console.log(articles);
	url_link = document.getElementById("img_url").value;
		console.log(url_link);
		
		
	//add fields to a variable
	var blog_content="";
	blog_content+= img+url_link+img_end+"<br>"+"<b>"+title+"</b>"+"<br>"+articles+"<br>"+"<br>";
	
	//create a div element to be placed inside the HTML id "content"
	var blog=document.createElement('div');
	
	blog.id=count; //the id needs to be incremental so that it can create new entries with different id's
	blog.className='col-4'; //specifies the display format
	
	//add the empty blog to the "content" area
	document.getElementById("content").appendChild(blog);
	
	//fill the blog with the fields
	document.getElementById(count).innerHTML=blog_content;
	count++;	
}
